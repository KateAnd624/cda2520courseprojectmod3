import React from 'react';

function Form(props) {
  return (
    <form>
      <input
        type="text"
        id="new-note-input"
        className="input input__lg"
        name="text"
        autoComplete="off"
      />
      <button type="submit" className="btn btn__primary btn__lg">
        Submit Note
      </button>
    </form>
  );
}

export default Form;
