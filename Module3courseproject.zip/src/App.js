import React from 'react';
import Form from "./components/Form";
import Notes from "./components/Notes";

function App(props) {
  const noteList = props.note.map(note => (
    <Notes
      id={note.id}
      name={note.name}
      completed={note.completed}
      key={note.id}
    />
  )
);
    return (
    <div className="note stack-large">
      <h1>NotesMachine</h1>
      <Form />
      <ul
      className="note-list stack-large stack-exception"
      aria-labelledby="list-heading"
    >
      {noteList}
    </ul>
    </div>
  );
}

export default App;
